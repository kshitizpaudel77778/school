<div class="container">
	<div class="jumbotron sejarah cf marginTop60px">
		<h2><?= $sejarah->judul_sejarah??''; ?></h2>
		<div class="col-md-12 marginTop60px">
			<?= $sejarah->sejarah??''; ?>
		</div>
	</div>
</div>