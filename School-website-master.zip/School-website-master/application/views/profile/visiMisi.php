<div class="container">
	<div class="visiMisi cf">
		<div class="col-md-6">
			<div class="alert alert-success" role="alert">
	  			<h2>Visi</h2>
	  			<?= $visi_misi->visi??''; ?>
			</div>
		</div>
		<div class="col-md-6">
			<div class="alert alert-info" role="alert">
				<h2>Misi</h2>
				<?= $visi_misi->misi??''; ?>
			</div>
		</div>
	</div>
</div>