# Website Sekolah

### Teknologi apa saja yang digunakan?
1. codeigniter 3.1.10
2. bootstrap
3. foundation icon
4. ckeditor
5. Masonry layout
6. Lazy loading
7. Infinite scroll

### Fiturnya apa saja?
1. Multiuser (operator, admin, superAdmin)
2. Home
	- Management pengunguman
	- Management berita
3. Riwayat sekolah
	- Management sejarah
	- Management kepala sekolah
	- Management visi misi
	- Management struktur sekolah
4. Management File download
5. Management Data Jurusan
6. Management Fasilitas Sekolah
7. Guru & Staf/Karyawan
	- Management Data Duru
	- Management Data staf
8. Galeri
	- Management Foto
	- Management video
9. Management Kontak
10. Pengaturan
	- Management Logo Sekolah
	- Management Opening Word
11. Management User

### Memerlukan
1. PHP7.3.20 atau 7.4

### Info login
Untuk hak akses Super Admin

**No**|**Username**|**Password**
:----:|:----:|:----:
1|reza|reza

Untuk hak akses Admin

**NO**|**Username**|**Password**
:----:|:----:|:----:
1|dian|dian

Untuk hak akses Operator

**No**|**Username**|**Password**
:----:|:----:|:----:
1|prisko|1234
